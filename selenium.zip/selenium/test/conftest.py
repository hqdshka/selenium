"""Fixture"""

import pytest
from webdriver_manager.firefox import GeckoDriverManager
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.firefox.options import Options

@pytest.fixture(scope="session")
def browser():
    """Main fixture"""
    firefox_options = Options()
    firefox_options.add_argument("--no sandbox")
    firefox_options.add_argument("start-maximized")
    firefox_options.add_argument("--disable-infobars")
    firefox_options.add_argument("disable-extensions")

    service = Service(GeckoDriverManager().install())
    driver = webdriver.Firefox(service=service, options=firefox_options)
    yield driver
    driver.quit()
