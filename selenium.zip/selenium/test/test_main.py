""" MyTests"""
#import pytest
from selenium.webdriver.common.by import By
URL = "http://www.automationpractice.pl/index.php"
def test_smoke(browser):
    """" SMK-1 Smoke """

    browser.get(URL)

    button = browser.find_element(By.CSS_SELECTOR, value=".sf-menu>li:nth-child(1)>a:nth-child(1)")
    assert button.text == "WOMEN", "Unexpected title"

def test_search1(browser):
    """TS-1 Search test empty"""

    browser.get(URL)

    button = browser.find_element(By.CSS_SELECTOR, value="button.btn:nth-child(5)")
    button.click()
    alert = browser.find_element(By.CSS_SELECTOR, value =".alert")
    assert alert.text == "Please enter a search keyword", "No search"

def test_search2(browser):
    """TS-1 Search """
    browser.get(URL)
    query = browser.find_element(By.ID, value="search_query_top")
    query.click()
    query.send_keys("qwet6r")

    button = browser.find_element(By.CSS_SELECTOR, value="button.btn:nth-child(5)")
    button.click()
    alert = browser.find_element(By.CSS_SELECTOR, value =".heading-counter")
    assert alert.text == "0 results have been found.", "No search"

def test_click_product(browser):
    """TCP-1 Click product"""
    browser.get("http://www.automationpractice.pl/index.php?id_category=3&controller=category")
    product = browser.find_element(By.CSS_SELECTOR, value='[class = "product-image-container"]')
    product.click()

    h3 = browser.find_element(By.CSS_SELECTOR, value="section.page-product-box:nth-child(2) > h3:nth-child(1)")
    assert h3.text == "DATA SHEET", ""
